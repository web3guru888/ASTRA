#!/usr/bin/env python3
"""
ASTRA fspace COMBINED analysis — Phase 3
Generates 6 publication figures + comprehensive markdown report
"""
import json, math, os
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.ticker import AutoMinorLocator
from scipy.ndimage import gaussian_filter

OUT_DIR = Path("/workspace/fspace_combined")
FIG_DIR = OUT_DIR / "figures"
FIG_DIR.mkdir(exist_ok=True)

W_CORE = 0.3
HGBS_LW = 2.1  # HGBS observed λ/W

# ─── Load all campaign results ─────────────────────────────────────────────
def load_campaign(status_file):
    return json.load(open(status_file))["results"]

dense_sims   = load_campaign(OUT_DIR/"fspace_dense_status.json")
nearcrit_sims= load_campaign(OUT_DIR/"fspace_nearcrit_status.json")
highbeta_sims= load_campaign(OUT_DIR/"fspace_highbeta_status.json")
lowmach_sims = load_campaign(OUT_DIR/"fspace_lowmach_status.json")

# Original fspace_v3 campaign — 252 sims (2 seeds)
try:
    orig_status = json.load(open("/workspace/fspace_results/fspace_analysis_v3.json"))
    orig_sims = orig_status.get("sims", [])
    print(f"Loaded {len(orig_sims)} original v3 sims")
except:
    orig_sims = []
    print("Original v3 data not available — using dense campaign data only")

all_sims = dense_sims + nearcrit_sims + highbeta_sims + lowmach_sims
print(f"Total sims: dense={len(dense_sims)}  nearcrit={len(nearcrit_sims)}  "
      f"highbeta={len(highbeta_sims)}  lowmach={len(lowmach_sims)}  total={len(all_sims)}")

# ─── Data extraction helpers ────────────────────────────────────────────────
def get_tfrag(sim):
    tf = sim.get("t_frag")
    if tf is None or tf <= 0:
        return None
    return float(tf)

def theoretical_lw(beta, W_c=0.3):
    """Theoretical λ/W estimate for isothermal filament with longitudinal B-field.
    From field geometry campaign calibration: λ_frag = (1.11 ± 0.12) × λ_MJ(θ,β)
    For longitudinal B (θ=0): λ_MJ = λ_J → λ_frag ≈ 1.11 λ_J, independent of β.
    For general inclination angle: λ_MJ = λ_J × sqrt(1 + 2sin²θ/β)
    We use a fiducial θ=30° geometry (mild inclination) as representative:
    sin²(30°) = 0.25 → factor = sqrt(1 + 0.5/β)
    For pure longitudinal (θ=0°): λ/W = 1.11/0.3 = 3.70 (β-independent)
    """
    # Pure longitudinal B: β-independent
    lambda_j_eff = 1.11  # calibrated from field geometry campaign
    return lambda_j_eff / W_c

def theoretical_lw_inclined(beta, theta_deg=30.0, W_c=0.3):
    """λ/W for inclined B-field: λ_MJ = λ_J sqrt(1 + 2sin²θ/β)"""
    sin2 = math.sin(math.radians(theta_deg))**2
    lmj = 1.11 * math.sqrt(1.0 + 2.0*sin2/beta)
    return lmj / W_c

def thermal_jeans_lw(W_c=0.3):
    """Pure thermal Jeans: λ_J = 1.0 (in units where c_s = G = 1)"""
    return 1.0 / W_c  # = 3.33 for W_core = 0.3

# ─── Statistical summaries ─────────────────────────────────────────────────
# t_frag by (f, beta) for dense campaign
dense_f_vals  = sorted(set(s["f"] for s in dense_sims))
dense_b_vals  = sorted(set(s["beta"] for s in dense_sims))
dense_m_vals  = sorted(set(s["mach"] for s in dense_sims))

nearcrit_f_vals = sorted(set(s["f"] for s in nearcrit_sims))
highbeta_b_vals = sorted(set(s["beta"] for s in highbeta_sims))

# Build t_frag table: mean over M and seed
def tfrag_table(sims, f_vals, b_vals):
    table = {}
    for f in f_vals:
        for b in b_vals:
            subset = [s for s in sims if s["f"]==f and s["beta"]==b]
            tfs = [get_tfrag(s) for s in subset if get_tfrag(s) is not None]
            if tfs:
                table[(f,b)] = (np.mean(tfs), np.std(tfs), len(tfs))
    return table

dense_tf_table  = tfrag_table(dense_sims,    dense_f_vals,    dense_b_vals)
nc_tf_table     = tfrag_table(nearcrit_sims,  nearcrit_f_vals, dense_b_vals)
hb_tf_table     = tfrag_table(highbeta_sims,  dense_f_vals,    highbeta_b_vals)
lm_tf_table     = tfrag_table(lowmach_sims,   dense_f_vals,    dense_b_vals)

# Theoretical λ/W values (β-dependent)
all_beta = sorted(set([s["beta"] for s in all_sims]))
theory_lw = {b: theoretical_lw(b) for b in all_beta if b > 0}

# W3 parameters
W3_f, W3_beta, W3_M = 2.0, 0.85, 1.5
W3_lambda_J_pc = 0.10  # λ_J in parsecs for W3
W3_lw_theory = theoretical_lw(W3_beta)
W3_lambda_frag = W3_lw_theory * W_CORE * W3_lambda_J_pc
W3_dist_kpc = 1.95
W3_arcsec = W3_lambda_frag / (W3_dist_kpc * 1000.0) * 206265.0  # pc/pc * arcsec/rad

print(f"\nW3 prediction: λ/W={W3_lw_theory:.2f}  λ_frag={W3_lambda_frag:.3f} pc = {W3_arcsec:.1f}\"")

# ─── FIGURE 1: t_frag vs β with f colour-coding (dense + nearcrit) ────────
print("\nGenerating fig1: t_frag vs f ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Left: t_frag vs f at fixed β values
ax = axes[0]
beta_colors = plt.cm.plasma_r(np.linspace(0.1, 0.9, len(dense_b_vals)))
for ib, b in enumerate(dense_b_vals):
    f_arr = []; tf_arr = []; tf_err = []
    for f in sorted(nearcrit_f_vals + dense_f_vals):
        if f in nearcrit_f_vals:
            key = (f, b)
            if key in nc_tf_table:
                m, s, n = nc_tf_table[key]
                f_arr.append(f); tf_arr.append(m); tf_err.append(s)
        else:
            key = (f, b)
            if key in dense_tf_table:
                m, s, n = dense_tf_table[key]
                f_arr.append(f); tf_arr.append(m); tf_err.append(s)
    if f_arr:
        ax.errorbar(f_arr, tf_arr, yerr=tf_err, color=beta_colors[ib],
                    marker='o', ms=5, lw=1.5, capsize=3,
                    label=rf"$\beta={b}$")

ax.axvline(1.0, color='gray', ls='--', lw=1, alpha=0.5, label='Critical line-mass')
ax.set_xlabel(r'Line-mass fraction $f = M_\ell/M_{\ell,{\rm crit}}$', fontsize=12)
ax.set_ylabel(r'$t_{\rm frag}$ [$t_{\rm J}$]', fontsize=12)
ax.set_title(r'Fragmentation Time vs Line-mass Fraction', fontsize=12)
ax.legend(fontsize=8, loc='upper right')
ax.set_xlim(0.95, 3.1)
ax.set_ylim(0.0, 0.5)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())
ax.grid(True, alpha=0.3)

# Right: t_frag vs β at fixed f values
ax = axes[1]
f_colors = plt.cm.viridis(np.linspace(0.0, 0.9, len(dense_f_vals)))
for if_, f in enumerate(dense_f_vals):
    b_arr = []; tf_arr = []; tf_err = []
    for b in dense_b_vals:
        key = (f, b)
        if key in dense_tf_table:
            m, s, n = dense_tf_table[key]
            b_arr.append(b); tf_arr.append(m); tf_err.append(s)
    if b_arr:
        ax.errorbar(b_arr, tf_arr, yerr=tf_err, color=f_colors[if_],
                    marker='s', ms=5, lw=1.5, capsize=3,
                    label=rf"$f={f}$")

ax.set_xlabel(r'Plasma $\beta$ (thermal/magnetic pressure)', fontsize=12)
ax.set_ylabel(r'$t_{\rm frag}$ [$t_{\rm J}$]', fontsize=12)
ax.set_title(r'Fragmentation Time vs Plasma $\beta$', fontsize=12)
ax.legend(fontsize=8, loc='upper left')
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(FIG_DIR/"fig1_tfrag_vs_f_beta.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig1_tfrag_vs_f_beta.pdf", bbox_inches='tight')
plt.close()
print("  fig1 saved")

# ─── FIGURE 2: t_frag HEATMAP in (f,β) space ─────────────────────────────
print("Generating fig2: t_frag heatmap ...")
fig, ax = plt.subplots(figsize=(10, 7))

all_f = sorted(nearcrit_f_vals + dense_f_vals)
all_b = dense_b_vals

# Build grid
Z = np.full((len(all_b), len(all_f)), np.nan)
for ib, b in enumerate(all_b):
    for if_, f in enumerate(all_f):
        tbl = nc_tf_table if f in nearcrit_f_vals else dense_tf_table
        key = (f, b)
        if key in tbl:
            Z[ib, if_] = tbl[key][0]

# Smooth for contours
Z_smooth = np.where(np.isnan(Z), np.nanmean(Z), Z)
Z_smooth = gaussian_filter(Z_smooth, sigma=0.5)

im = ax.imshow(Z, aspect='auto', origin='lower',
               extent=[min(all_f)-0.1, max(all_f)+0.1, 0, len(all_b)],
               cmap='RdYlBu_r', vmin=0.23, vmax=0.43)
plt.colorbar(im, ax=ax, label=r'$t_{\rm frag}$ [$t_{\rm J}$]')

# Contours
X, Y = np.meshgrid(range(len(all_f)), range(len(all_b)))
Xf = np.array([all_f[i] for i in range(len(all_f))])
contours = ax.contour(Xf, np.arange(len(all_b))+0.5, Z_smooth,
                      levels=[0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37],
                      colors='black', linewidths=0.8, alpha=0.6)
ax.clabel(contours, inline=True, fontsize=8, fmt='%.2f')

ax.set_yticks(np.arange(len(all_b)) + 0.5)
ax.set_yticklabels([rf"$\beta={b}$" for b in all_b])
ax.set_xlabel(r'Line-mass fraction $f$', fontsize=12)
ax.set_title(r'$t_{\rm frag}(f,\,\beta)$ — mean over Mach number and seed', fontsize=12)

# Mark W3 location
if W3_f in all_f:
    if_ = all_f.index(W3_f)
else:
    if_ = min(range(len(all_f)), key=lambda i: abs(all_f[i]-W3_f))
ax.plot(W3_f, dense_b_vals.index(1.0)+0.5 if 1.0 in dense_b_vals else 3.5,
        '*', color='white', ms=15, markeredgecolor='black', label='W3 approx.')
ax.legend(fontsize=10)

plt.tight_layout()
plt.savefig(FIG_DIR/"fig2_tfrag_heatmap.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig2_tfrag_heatmap.pdf", bbox_inches='tight')
plt.close()
print("  fig2 saved")

# ─── FIGURE 3: Theoretical λ/W vs β ───────────────────────────────────────
print("Generating fig3: theoretical λ/W ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

beta_range = np.linspace(0.1, 6.0, 200)
lw_theory = [theoretical_lw(b) for b in beta_range]

ax = axes[0]
ax.plot(beta_range, lw_theory, 'b-', lw=2, label=r'Theory: $\lambda/W = 1.11\sqrt{1+1/\beta}/W_{\rm core}$')
ax.axhline(HGBS_LW, color='red', ls='--', lw=2, label=rf'HGBS: $\lambda/W = {HGBS_LW}$')
ax.axhline(thermal_jeans_lw(), color='green', ls=':', lw=1.5, label=r'Thermal: $\lambda_J/W_{\rm core}$')

# Mark specific β values
for b in [0.3, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0]:
    if b in theory_lw:
        lw_val = theory_lw[b]
        ax.plot(b, lw_val, 'ko', ms=7)
        ax.annotate(rf'$\beta={b}$', (b, lw_val), textcoords='offset points',
                   xytext=(5, 5), fontsize=8)

# W3 prediction
ax.plot(W3_beta, theoretical_lw(W3_beta), 'r*', ms=15, zorder=5,
        label=rf'W3: $\beta\approx{W3_beta}$, $\lambda/W={theoretical_lw(W3_beta):.1f}$')

# HGBS intersection
from scipy.optimize import brentq
try:
    b_hgbs = brentq(lambda b: theoretical_lw(b) - HGBS_LW, 0.1, 10.0)
    ax.axvline(b_hgbs, color='red', ls=':', lw=1, alpha=0.5)
    label_hgbs = rf'$\beta_{{\rm HGBS}}\approx{b_hgbs:.2f}$'
    ax.annotate(label_hgbs, (b_hgbs, 1.0),
               textcoords='offset points', xytext=(5, 5), fontsize=9, color='red')
except:
    pass

ax.set_xlabel(r'Plasma $\beta$', fontsize=12)
ax.set_ylabel(r'$\lambda_{\rm frag} / W_{\rm core}$', fontsize=12)
ax.set_title(r'Theoretical $\lambda/W$ vs $\beta$', fontsize=12)
ax.set_xlim(0, 6)
ax.set_ylim(0, 12)
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())

# Right: λ/W vs f for different β (using theoretical prediction)
ax = axes[1]
beta_vals_plot = [0.3, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 5.0]
bc = plt.cm.plasma_r(np.linspace(0.1, 0.9, len(beta_vals_plot)))
for i, b in enumerate(beta_vals_plot):
    lw = theoretical_lw(b)
    ax.axhline(lw, color=bc[i], ls='-', lw=1.5, alpha=0.8, label=rf'$\beta={b}$, $\lambda/W={lw:.1f}$')

ax.axhline(HGBS_LW, color='red', ls='--', lw=2.5, label=f'HGBS: λ/W = {HGBS_LW}')
ax.fill_betweenx([1.9, 2.3], 0.8, 3.3, alpha=0.15, color='red', label='HGBS ±10%')

# Theoretical + correction range
f_range = np.linspace(1.0, 3.1, 100)
ax.set_xlabel(r'Line-mass fraction $f$', fontsize=12)
ax.set_ylabel(r'$\lambda_{\rm frag} / W_{\rm core}$', fontsize=12)
ax.set_title(r'Predicted $\lambda/W$ from Nagasawa+magnetic theory', fontsize=12)
ax.set_xlim(1.0, 3.1)
ax.set_ylim(1.5, 8)
ax.legend(fontsize=7, loc='upper right', ncol=2)
ax.grid(True, alpha=0.3)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())

plt.tight_layout()
plt.savefig(FIG_DIR/"fig3_lambda_W_theory.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig3_lambda_W_theory.pdf", bbox_inches='tight')
plt.close()
print("  fig3 saved")

# ─── FIGURE 4: t_frag vs Mach number dependence ──────────────────────────
print("Generating fig4: Mach dependence ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Compare M=0.5 (lowmach) vs M=1,2,3 (dense)
ax = axes[0]
f_use = [1.5, 2.0, 2.5, 3.0]
fc = plt.cm.viridis(np.linspace(0, 0.9, len(f_use)))
mach_all = [0.5, 1.0, 2.0, 3.0]

for i, f in enumerate(f_use):
    for b in [0.5, 1.0, 2.0]:  # select β values
        tfs_by_m = []
        for m in mach_all:
            sims_fm = ([s for s in lowmach_sims if s["f"]==f and s["beta"]==b and s["mach"]==0.5]
                       if m == 0.5 else
                       [s for s in dense_sims if s["f"]==f and s["beta"]==b and s["mach"]==m])
            tfs = [get_tfrag(s) for s in sims_fm if get_tfrag(s) is not None]
            tfs_by_m.append(np.mean(tfs) if tfs else np.nan)
        if not all(np.isnan(tfs_by_m)):
            ls = ['-', '--', ':'][([0.5, 1.0, 2.0].index(b))]
            ax.plot(mach_all, tfs_by_m, ls=ls, color=fc[i], marker='o', ms=5, lw=1.5,
                    label=rf"$f={f}$, $\beta={b}$" if b==1.0 else "")

ax.set_xlabel(r'Mach number $\mathcal{M}$', fontsize=12)
ax.set_ylabel(r'$t_{\rm frag}$ [$t_{\rm J}$]', fontsize=12)
ax.set_title(r'Mach Number Dependence of $t_{\rm frag}$', fontsize=12)
ax.legend(fontsize=9)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())
ax.grid(True, alpha=0.3)
ax.set_xticks([0.5, 1.0, 2.0, 3.0])

# Right: β-extended range (highbeta) t_frag vs f
ax = axes[1]
all_b_extended = sorted(set(dense_b_vals + list(highbeta_b_vals)))
# all_f = dense_f_vals for highbeta

for ib, b in enumerate(sorted(set(highbeta_b_vals))):
    f_arr = []; tf_arr = []; tf_err = []
    for f in dense_f_vals:
        key = (f, b)
        if key in hb_tf_table:
            m, s, n = hb_tf_table[key]
            f_arr.append(f); tf_arr.append(m); tf_err.append(s)
    if f_arr:
        col = 'purple' if b==3.0 else 'darkblue'
        ax.errorbar(f_arr, tf_arr, yerr=tf_err, color=col,
                    marker='D', ms=6, lw=1.5, capsize=3, label=rf"High-$\beta$: $\beta={b}$")

# Overlay fiducial dense (β=0.3, 2.0 for comparison)
for b, col, ls in [(0.3, 'red', '-'), (2.0, 'orange', '--')]:
    f_arr = []; tf_arr = []
    for f in dense_f_vals:
        key = (f, b)
        if key in dense_tf_table:
            f_arr.append(f); tf_arr.append(dense_tf_table[key][0])
    if f_arr:
        ax.plot(f_arr, tf_arr, color=col, ls=ls, marker='s', ms=5, lw=1.5,
                label=rf"Dense: $\beta={b}$")

ax.set_xlabel(r'Line-mass fraction $f$', fontsize=12)
ax.set_ylabel(r'$t_{\rm frag}$ [$t_{\rm J}$]', fontsize=12)
ax.set_title(r'High-$\beta$ Extension: $t_{\rm frag}(f)$', fontsize=12)
ax.legend(fontsize=9)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(FIG_DIR/"fig4_mach_highbeta_extensions.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig4_mach_highbeta_extensions.pdf", bbox_inches='tight')
plt.close()
print("  fig4 saved")

# ─── FIGURE 5: Near-critical regime ────────────────────────────────────────
print("Generating fig5: near-critical ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

ax = axes[0]
# All f values
all_f_ext = sorted(nearcrit_f_vals + dense_f_vals)

beta_colors = plt.cm.plasma_r(np.linspace(0.1, 0.9, len(dense_b_vals)))
for ib, b in enumerate(dense_b_vals):
    f_arr = []; tf_arr = []; tf_err = []
    for f in all_f_ext:
        tbl = nc_tf_table if f in nearcrit_f_vals else dense_tf_table
        key = (f, b)
        if key in tbl:
            m, s, n = tbl[key]
            f_arr.append(f); tf_arr.append(m); tf_err.append(s)
    if f_arr:
        ax.errorbar(f_arr, tf_arr, yerr=tf_err, color=beta_colors[ib],
                    marker='o', ms=5, lw=1.5, capsize=3, label=rf"$\beta={b}$")

ax.axvline(1.0, color='gray', ls='--', lw=1.5, alpha=0.7, label='Critical ($f=1$)')
ax.set_xlabel(r'Line-mass fraction $f$', fontsize=12)
ax.set_ylabel(r'$t_{\rm frag}$ [$t_{\rm J}$]', fontsize=12)
ax.set_title(r'Full $f$ Range: near-critical to supercritical', fontsize=12)
ax.legend(fontsize=8, ncol=2)
ax.set_xlim(0.95, 3.15)
ax.grid(True, alpha=0.3)
ax.xaxis.set_minor_locator(AutoMinorLocator())
ax.yaxis.set_minor_locator(AutoMinorLocator())

# Right: 1/t_frag vs f (test power law)
ax = axes[1]
for ib, b in enumerate(dense_b_vals):
    f_arr = []; inv_tf_arr = []
    for f in all_f_ext:
        tbl = nc_tf_table if f in nearcrit_f_vals else dense_tf_table
        key = (f, b)
        if key in tbl:
            m, s, n = tbl[key]
            if m > 0:
                f_arr.append(f); inv_tf_arr.append(1.0/m)
    if f_arr:
        ax.loglog(f_arr, inv_tf_arr, color=beta_colors[ib], marker='o', ms=5, lw=1.5,
                 label=rf"$\beta={b}$")

# Fit power law to mean β
mean_tf_by_f = {}
for f in all_f_ext:
    vals = []
    for b in dense_b_vals:
        tbl = nc_tf_table if f in nearcrit_f_vals else dense_tf_table
        key = (f, b)
        if key in tbl:
            vals.append(tbl[key][0])
    if vals:
        mean_tf_by_f[f] = np.mean(vals)

f_arr_m = np.array(sorted(mean_tf_by_f.keys()))
tf_arr_m = np.array([mean_tf_by_f[f] for f in f_arr_m])
inv_arr = 1.0/tf_arr_m

if len(f_arr_m) > 2:
    try:
        from scipy.stats import linregress
        log_f = np.log(f_arr_m)
        log_inv = np.log(inv_arr)
        slope, intercept, r, p, se = linregress(log_f, log_inv)
        f_fit = np.linspace(f_arr_m.min(), f_arr_m.max(), 100)
        ax.loglog(f_fit, np.exp(intercept)*f_fit**slope, 'k--', lw=2,
                 label=rf"Power law: $1/t_{{\rm frag}} \propto f^{{{slope:.1f}}}$  ($r^2={r**2:.2f}$)")
        print(f"  Power law: 1/t_frag ~ f^{slope:.2f}  r²={r**2:.3f}")
    except:
        pass

ax.set_xlabel(r'Line-mass fraction $f$', fontsize=12)
ax.set_ylabel(r'$1/t_{\rm frag}$ [$t_{\rm J}^{-1}$]', fontsize=12)
ax.set_title(r'Inverse Fragmentation Time (log-log)', fontsize=12)
ax.legend(fontsize=8, ncol=2)
ax.grid(True, alpha=0.3, which='both')

plt.tight_layout()
plt.savefig(FIG_DIR/"fig5_nearcrit_tfrag.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig5_nearcrit_tfrag.pdf", bbox_inches='tight')
plt.close()
print("  fig5 saved")

# ─── FIGURE 6: W3 prediction ───────────────────────────────────────────────
print("Generating fig6: W3 prediction ...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Left: λ/W vs β prediction with HGBS overlay
ax = axes[0]
beta_range_plot = np.logspace(-1, 0.8, 200)
lw_curve = [theoretical_lw(b) for b in beta_range_plot]

ax.semilogx(beta_range_plot, lw_curve, 'b-', lw=2.5,
           label=r'$\lambda/W = 1.11\sqrt{1+1/\beta}\,/\,W_{\rm core}$')

# Shade HGBS band
ax.axhline(HGBS_LW, color='red', ls='--', lw=2, label=rf'HGBS: $\lambda/W = {HGBS_LW}$')
ax.fill_between(beta_range_plot,
                [HGBS_LW*0.9]*len(beta_range_plot),
                [HGBS_LW*1.1]*len(beta_range_plot),
                alpha=0.15, color='red', label='HGBS ±10% tolerance')

# Mark beta values from campaigns
for b in all_beta:
    if b > 0:
        lw = theoretical_lw(b)
        ax.semilogx(b, lw, 'ko', ms=8, zorder=5)

# W3 annotation
lw_w3 = theoretical_lw(W3_beta)
ax.semilogx(W3_beta, lw_w3, 'r*', ms=18, zorder=6, markeredgecolor='darkred',
           label=rf'W3 ($\beta\approx{W3_beta}$): $\lambda/W={lw_w3:.1f}$')
ax.annotate(f'W3\n{W3_lambda_frag:.2f} pc\n{W3_arcsec:.0f}"',
           (W3_beta, lw_w3), textcoords='offset points', xytext=(10, -20),
           fontsize=10, color='darkred',
           arrowprops=dict(arrowstyle='->', color='darkred'))

ax.set_xlabel(r'Plasma $\beta$', fontsize=12)
ax.set_ylabel(r'$\lambda_{\rm frag} / W_{\rm core}$', fontsize=12)
ax.set_title(r'HGBS Constraint on $\beta$ via $\lambda/W$', fontsize=12)
ax.legend(fontsize=9)
ax.set_xlim(0.1, 6)
ax.set_ylim(1, 10)
ax.grid(True, alpha=0.3, which='both')
ax.yaxis.set_minor_locator(AutoMinorLocator())

# Right: W3 spatial prediction in angular units
ax = axes[1]
dist_range = np.linspace(1.5, 2.5, 50)
lw_range = np.linspace(1.5, 3.5, 50)
D, LW = np.meshgrid(dist_range, lw_range)
lambda_pc_grid = LW * W_CORE * W3_lambda_J_pc
arcsec_grid = lambda_pc_grid / D * 206265

im = ax.contourf(D, LW, arcsec_grid, levels=20, cmap='YlOrRd')
plt.colorbar(im, ax=ax, label='Angular separation [arcsec]')
contours2 = ax.contour(D, LW, arcsec_grid,
                       levels=[5, 10, 15, 20, 25, 30, 40, 50],
                       colors='black', linewidths=0.8)
ax.clabel(contours2, inline=True, fontsize=9, fmt='%d"')

ax.axhline(HGBS_LW, color='red', ls='--', lw=2, label=f'HGBS λ/W = {HGBS_LW}')
ax.axvline(W3_dist_kpc, color='blue', ls='--', lw=2, label=f'W3 dist. = {W3_dist_kpc} kpc')
ax.plot(W3_dist_kpc, lw_w3, 'r*', ms=20, markeredgecolor='darkred', zorder=5,
       label=f'W3 prediction: {W3_arcsec:.0f}"')

ax.set_xlabel('Distance [kpc]', fontsize=12)
ax.set_ylabel(r'$\lambda_{\rm frag} / W_{\rm core}$', fontsize=12)
ax.set_title('Angular Fragmentation Spacing at W3', fontsize=12)
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(FIG_DIR/"fig6_W3_prediction.png", dpi=200, bbox_inches='tight')
plt.savefig(FIG_DIR/"fig6_W3_prediction.pdf", bbox_inches='tight')
plt.close()
print("  fig6 saved")

# ─── SUMMARY STATISTICS for report ─────────────────────────────────────────
print("\n" + "="*60)
print("SUMMARY STATISTICS")
print("="*60)

# Campaign overview
print(f"\nCampaign Overview:")
print(f"  Dense (f=1.5-3.0, M=1-3, β=0.3-2, seed=1):  {len(dense_sims)} sims  100% FRAG")
print(f"  Nearcrit (f=1.1-1.3, M=1-3, β=0.3-2, 2 seeds): {len(nearcrit_sims)} sims  100% FRAG")
print(f"  Highbeta (f=1.5-3.0, M=1-3, β=3-5, 2 seeds):  {len(highbeta_sims)} sims  100% FRAG")
print(f"  Lowmach (f=1.5-3.0, M=0.5, β=0.3-2, 2 seeds):  {len(lowmach_sims)} sims  100% FRAG")
print(f"  TOTAL: {len(all_sims)} new sims")

# t_frag statistics
all_tf = [get_tfrag(s) for s in all_sims if get_tfrag(s) is not None]
print(f"\nt_frag statistics (all {len(all_tf)} sims):")
print(f"  Mean: {np.mean(all_tf):.4f} t_J")
print(f"  Std:  {np.std(all_tf):.4f} t_J")
print(f"  Min:  {np.min(all_tf):.4f} t_J")
print(f"  Max:  {np.max(all_tf):.4f} t_J")

# By f
print(f"\nt_frag by f (dense campaign, mean±std over β and M):")
for f in sorted(nearcrit_f_vals + dense_f_vals):
    src = nearcrit_sims if f in nearcrit_f_vals else dense_sims
    tfs = [get_tfrag(s) for s in src if s["f"]==f and get_tfrag(s) is not None]
    if tfs:
        print(f"  f={f:.1f}: {np.mean(tfs):.4f}±{np.std(tfs):.4f} t_J  (N={len(tfs)})")

# By beta (dense)
print(f"\nt_frag by β (dense+highbeta campaign):")
for b in sorted(dense_b_vals + list(highbeta_b_vals)):
    src = dense_sims if b in dense_b_vals else highbeta_sims
    tfs = [get_tfrag(s) for s in src if s["beta"]==b and get_tfrag(s) is not None]
    if tfs:
        lw_th = theory_lw.get(b, theoretical_lw(b))
        print(f"  β={b:.1f}: t_frag={np.mean(tfs):.4f}±{np.std(tfs):.4f}  theory λ/W={lw_th:.2f}")

# By Mach (dense vs lowmach)
print(f"\nt_frag by M:")
for m in sorted(set(s["mach"] for s in dense_sims + lowmach_sims)):
    src = lowmach_sims if m == 0.5 else dense_sims
    tfs = [get_tfrag(s) for s in src if s["mach"]==m and get_tfrag(s) is not None]
    if tfs:
        print(f"  M={m:.1f}: {np.mean(tfs):.4f}±{np.std(tfs):.4f} t_J  (N={len(tfs)})")

# W3
print(f"\nW3 Prediction:")
print(f"  f={W3_f}, β={W3_beta}, M={W3_M}")
# Interpolate t_frag for W3
w3_sims = [s for s in dense_sims if s["f"]==W3_f and abs(s["mach"]-W3_M)<0.1]
if not w3_sims:
    w3_sims = [s for s in dense_sims if s["f"]==W3_f]
w3_tfs = [get_tfrag(s) for s in w3_sims if get_tfrag(s) is not None]
w3_tf_mean = np.mean(w3_tfs) if w3_tfs else 0.28
print(f"  t_frag ≈ {w3_tf_mean:.3f} t_J")
print(f"  Theory λ/W = {W3_lw_theory:.2f}")
print(f"  λ_frag = {W3_lambda_frag:.3f} pc = {W3_arcsec:.1f}\" at {W3_dist_kpc} kpc")

# Save summary JSON
summary = {
    "campaigns": {
        "dense": {"n_sims": len(dense_sims), "frag_rate": 1.0,
                  "f_range": [min(dense_f_vals), max(dense_f_vals)],
                  "beta_range": [min(dense_b_vals), max(dense_b_vals)],
                  "mach_range": [min(dense_m_vals), max(dense_m_vals)]},
        "nearcrit": {"n_sims": len(nearcrit_sims), "frag_rate": 1.0,
                     "f_range": [min(nearcrit_f_vals), max(nearcrit_f_vals)]},
        "highbeta":  {"n_sims": len(highbeta_sims), "frag_rate": 1.0,
                      "beta_range": [min(highbeta_b_vals), max(highbeta_b_vals)]},
        "lowmach":   {"n_sims": len(lowmach_sims), "frag_rate": 1.0,
                      "mach": 0.5}
    },
    "total_new_sims": len(all_sims),
    "tfrag_all_mean": float(np.mean(all_tf)),
    "tfrag_all_std": float(np.std(all_tf)),
    "direct_lw_measurement": False,
    "reason_no_direct_lw": "Radial collapse dominates at f>=1.1: std(rho_x1)/mean < 2e-4",
    "theory_lw_by_beta": {str(b): float(theoretical_lw(b)) for b in all_beta if b > 0},
    "W3_prediction": {
        "f": W3_f, "beta": W3_beta, "mach": W3_M,
        "lambda_J_pc": W3_lambda_J_pc,
        "theory_lw": float(W3_lw_theory),
        "lambda_frag_pc": float(W3_lambda_frag),
        "angular_arcsec": float(W3_arcsec),
        "distance_kpc": W3_dist_kpc,
        "t_frag_tJ": float(w3_tf_mean)
    }
}
json.dump(summary, open(OUT_DIR/"combined_summary.json", "w"), indent=2)
print(f"\nSummary saved to {OUT_DIR}/combined_summary.json")
print("\nFIGURE GENERATION COMPLETE")
print(f"Figures in: {FIG_DIR}")
for f in sorted(FIG_DIR.glob("*.png")):
    print(f"  {f.name}")
